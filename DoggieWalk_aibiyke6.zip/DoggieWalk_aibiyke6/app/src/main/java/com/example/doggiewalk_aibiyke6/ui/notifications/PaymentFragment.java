package com.example.doggiewalk_aibiyke6.ui.notifications;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.doggiewalk_aibiyke6.databinding.FragmentPaymentBinding;

public class PaymentFragment extends Fragment {
    FragmentPaymentBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentPaymentBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.cardOptimaBank.setOnClickListener(v -> openBankAppOrWebsite("com.optimabank.android", "https://play.google.com/store/apps/details?id=kz.optimabank.optima24"));
        binding.cardBakaiBank.setOnClickListener(v -> openBankAppOrWebsite("com.bakaibank.android", "https://play.google.com/store/apps/details?id=kg.bta.mobilebank2"));
        binding.cardOMoney.setOnClickListener(v -> openBankAppOrWebsite("kg.o.money", "https://play.google.com/store/apps/details?id=kg.o.nurtelecom"));

    }

    private void openBankAppOrWebsite(String packageName, String url) {
        Intent launchIntent = requireActivity().getPackageManager().getLaunchIntentForPackage(packageName);
        if (launchIntent != null) {
            startActivity(launchIntent);
        } else {
            Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(webIntent);
        }
    }
}
