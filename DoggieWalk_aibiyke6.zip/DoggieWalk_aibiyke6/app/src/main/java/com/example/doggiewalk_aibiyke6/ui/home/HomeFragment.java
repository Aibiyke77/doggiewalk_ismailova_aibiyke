package com.example.doggiewalk_aibiyke6.ui.home;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.example.doggiewalk_aibiyke6.R;

public class HomeFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home, container, false);

        ImageView imageView = root.findViewById(R.id.imageView);
        Glide.with(this).asGif().load(R.drawable.dog_gif).into(imageView);

        ImageButton instagramButton = root.findViewById(R.id.btn_instagram);
        ImageButton telegramButton = root.findViewById(R.id.btn_telegram);
        ImageButton whatsappButton = root.findViewById(R.id.btn_whatsapp);

        instagramButton.setOnClickListener(v -> openUrl("https://www.instagram.com/dog?igsh=MWF4d2pkeDdyMGo2Ng=="));
        telegramButton.setOnClickListener(v -> openUrl("https://t.me/Ggd_77"));
        whatsappButton.setOnClickListener(v -> openUrl("https://wa.me/+996 705 240 205"));

        return root;
    }

    private void openUrl(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
}






