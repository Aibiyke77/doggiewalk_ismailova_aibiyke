package com.example.doggiewalk_aibiyke6.Model
        ;
public class Dog {

    private int imageResource;

    private String name;
    private String details;
    private String phone;

    public Dog(int imageResource,String name, String details, String phone) {
        this.imageResource = imageResource;
        this.name = name;
        this.details = details;
        this.phone = phone;
    }

    public int getImageResource() {
        return imageResource;
    }

    public String getName() {
        return name;
    }


    public String getDetails() {
        return details;
    }

    public String getPhone() {
        return phone;
    }
}

